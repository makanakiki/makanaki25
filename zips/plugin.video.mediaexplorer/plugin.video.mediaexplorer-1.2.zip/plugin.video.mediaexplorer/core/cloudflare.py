# -*- coding: utf-8 -*-
from core.libs import *


class Cloudflare:
    def __init__(self, response):
        self.start_time = time.time()
        self.timeout = 5
        self.domain = urlparse.urlparse(response["url"])[1]
        self.protocol = urlparse.urlparse(response["url"])[0]
        self.response = response

        pattern = r'var s,t,o,p,b,r,e,a,k,i,n,g,f, (?P<var>([^=]+)=\{"[^"]+":[^}]+\};).*?(?P<ops>\2.*?)' \
                  r'a.value = (?P<res>\(.*?\).toFixed\(\d+\);).*?, (?P<wait>\d+)\);.*?' \
                  r'<form id="challenge-form" action="(?P<auth_url>[^"]+)" method="(?P<method>[^"]+)".*?>' \
                  r'(?P<inputs>.*?)' \
                  r'</form>\s+(<div style="display:none;visibility:hidden;" id="cf-dn-[^"]+">(?P<div>[^<]+)</div>)?'

        match = re.compile(pattern, re.DOTALL).search(response['data'])
        if match:
            pattern = '<input type="hidden" name="(?P<name>[^"]+)" value="(?P<value>[^"]*)"'
            params = re.compile(pattern, re.DOTALL).finditer(match.group('inputs'))
            self.js_data = {
                "auth_url": match.group('auth_url'),
                "params": dict([(m.group('name'), m.group('value')) for m in params]),
                "res": match.group('res'),
                "div": match.group('div') or '',
                "var": match.group('var'),
                "ops": match.group('ops'),
                "wait": int(match.group('wait')) / 1000,
                "method": match.group('method'),
            }
        else:
            self.js_data = dict()

    @property
    def wait_time(self):
        if self.js_data:
            return self.js_data["wait"]

    @property
    def is_cloudflare(self):
        return self.response['code'] == 503 and bool(self.js_data)

    def get_url(self):
        # Metodo #1 (javascript)
        if self.js_data:
            import js2py
            ops = self.js_data['ops']

            ops = re.sub(
                r'function\(p\){return.*?\}\((.*?)\)\)\);',
                lambda x: str(ord(self.domain[int(js2py.eval_js(x.group(1)))])) + '));',
                ops
            )
            ops = re.sub(
                r'function\(p\){var p =.*?\}\(\)',
                self.js_data['div'],
                ops
            )
            jschl_answer = 'var t="%s";\nvar %s\n%s\n%s' % (self.domain, self.js_data["var"], ops, self.js_data['res'])
            self.js_data["params"]["jschl_answer"] = js2py.eval_js(jschl_answer)

            if self.js_data['method'] == 'POST':
                response = "%s://%s%s" % (
                    self.protocol,
                    self.domain,
                    self.js_data["auth_url"]
                ), self.js_data["params"]
            else:
                response = "%s://%s%s?%s" % (
                    self.protocol,
                    self.domain,
                    self.js_data["auth_url"],
                    urllib.urlencode(self.js_data["params"])
                ), False

            wait_time = self.js_data["wait"] - (time.time() - self.start_time)
            time.sleep(wait_time)

            return response
