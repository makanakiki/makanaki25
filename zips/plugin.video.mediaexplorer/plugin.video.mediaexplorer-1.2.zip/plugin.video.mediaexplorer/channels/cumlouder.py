# -*- coding: utf-8 -*-
from core.libs import *

HOST = 'https://www.cumlouder.com/es'


def mainlist(item):
    logger.trace()
    itemlist = list()

    itemlist.append(item.clone(
        type='label',
        label='Producciones CumLouder:'))

    itemlist.append(item.clone(
        group=True,
        type="item",
        action='videos',
        label='Útimos videos',
        url=HOST + '/series/novedades',
        content_type='videos'
    ))

    itemlist.append(item.clone(
        group=True,
        type="item",
        action='listcategorias',
        label='Categorías',
        url=HOST + '/categorias/',
        var='?show=cumlouder',
        content_type='items'
    ))

    itemlist.append(item.clone(
        group=True,
        type="item",
        action='listchicas',
        label='Chicas',
        url=HOST + '/chicas/',
        content_type='items'
    ))

    itemlist.append(item.clone())
    itemlist.append(item.clone(
        type='label',
        label='Otros videos:'))

    itemlist.append(item.clone(
        group=True,
        type="item",
        action='videos',
        label='Útimos videos',
        url=HOST + '/porno/',
        content_type='videos'
    ))

    itemlist.append(item.clone(
        group=True,
        type="item",
        action='listcategorias',
        label='Categorías',
        url=HOST + '/categorias/',
        var='?show=channels',
        content_type='items'
    ))

    itemlist.append(item.clone())
    itemlist.append(item.clone(
        action='search',
        label='Buscar',
        content_type='videos',
        category='adult',
        query=True,
        type='search'
    ))

    return itemlist


def listcategorias(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(item.url).data
    data = re.sub(r"\n|\r|\t|\s{2}|&nbsp;", "", data)

    patron = 'class="muestra-escena muestra-categoria show-tag" href="([^"]+)\?show=cumlouder".*?' \
             '<img class="thumb lazy".*?data-src="([^"]+).*?alt="([^"]+)"'

    for url, thumb, label in scrapertools.find_multiple_matches(data, patron):
        itemlist.append(item.clone(
            action='videos',
            label=unicode(label, 'utf8').capitalize().encode('utf8'),
            poster=thumb,
            url=urlparse.urljoin(HOST, url) + item.var,
            content_type='videos',
            type='item'
        ))

    if not item.url.endswith("2/"):
        itemlist += listcategorias(item.clone(url=item.url + "2/"))
    return sorted(itemlist, key=lambda x: x.label)


def listchicas(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(item.url).data
    data = re.sub(r"\n|\r|\t|\s{2}|&nbsp;", "", data)

    patron = 'class="muestra-escena muestra-pornostar show-girl" href="([^"]+)".*?data-src="([^"]+)".*?' \
             'alt="([^"]+)".*?<span class="videos"> <span class="ico-videos sprite"></span>([^<]+)</span>.*?' \
             '<span class="puntaje"> <span class="ico-puntaje sprite"></span>([^<]+)</span>'

    for url, thumb, label, num, ranking in scrapertools.find_multiple_matches(data, patron):
        itemlist.append(item.clone(
            action='videos',
            label='%s (%s) [%s]' % (label, ranking.strip(), num.strip()),
            poster=thumb,
            url=urlparse.urljoin(HOST, url),
            content_type='videos',
            type='item'
        ))

    # Paginador
    url_next = scrapertools.find_single_match(data, '<a href="([^"]+)" rel="nofollow">Siguiente »</a>')
    if itemlist and url_next:
        itemlist.append(item.clone(
            action='videos',
            url=urlparse.urljoin(HOST, url_next),
            type='next'
        ))

    return itemlist


def videos(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(item.url, add_referer=True).data
    data = re.sub(r"\n|\r|\t|\s{2}|&nbsp;", "", data)

    patron = '<a class="muestra-escena" href="([^"]+)".*?data-src="([^"]+)".*?alt="([^"]+)".*?' \
             '<span class="ico-minutos sprite"></span>([^<]+)</span>(.*?)</a>'

    for url, thumb, title, t, qlt in scrapertools.find_multiple_matches(data, patron):
        if not thumb.startswith('http'):
            thumb = 'https:' + thumb

        if "hd sprite" in qlt:
            title = "%s [%s]" % (title, 'HD')

        itemlist.append(item.clone(
            action='play',
            title="%s (%s)" % (title, t),
            url=urlparse.urljoin(HOST, url),
            thumb=thumb.replace('ep1.jpg', 'ep.jpg'),
            folder=False,
            type='video'
        ))

    # Paginador
    url_next = scrapertools.find_single_match(data, '<a href="([^"]+)"[^>]*>Siguiente »</a>')
    if itemlist and url_next:
        itemlist.append(item.clone(
            action='videos',
            url=urlparse.urljoin(HOST, url_next),
            type='next'
        ))

    return itemlist


def search(item):
    logger.trace()
    return videos(item.clone(url=HOST + '/buscar?q=%s' % item.query))


def play(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(item.url).data
    patron = '''<source src="([^"]+).*?res='([^']+)'''

    for url, res in scrapertools.find_multiple_matches(data, patron):
        itemlist.append(Video(url='https:' + url.replace('&amp;', '&'), res=res))

    return sorted(itemlist, key=lambda x: int(x.res) if x.res else 0, reverse=True)
