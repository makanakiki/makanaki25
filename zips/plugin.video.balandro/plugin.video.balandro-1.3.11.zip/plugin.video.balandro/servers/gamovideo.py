# -*- coding: utf-8 -*-

from core import httptools, scrapertools
from platformcode import logger
from lib import jsunpack

CUSTOM_HEADERS = {'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:66.0) Gecko/20100101 Firefox/66.0', 'Referer': 'http://gamovideo.com'}

def normalizar_url(page_url):
    if 'embed' in page_url:
        vid = scrapertools.find_single_match(page_url, "gamovideo.com/(?:embed-|)([a-z0-9]+)")
        return "http://gamovideo.com/" + vid
    return page_url


def get_video_url(page_url, url_referer=''):
    logger.info("(page_url='%s')" % page_url)
    video_urls = []
    
    page_url = normalizar_url(page_url)
    
    if url_referer: CUSTOM_HEADERS['Referer'] = url_referer
    CUSTOM_HEADERS['Cookie'] = 'pfm=1; sugamun=1;'

    data = httptools.downloadpage(page_url, headers=CUSTOM_HEADERS).data
    # ~ logger.debug(data)
    
    packer = scrapertools.find_single_match(data, "<script type='text/javascript'>(eval.function.p,a,c,k,e,d..*?)</script>")
    if packer:
        data = jsunpack.unpack(packer)
        # ~ logger.debug(data)

    mp4 = scrapertools.find_single_match(data, ',\{file\s*:\s*"([^"]+)')

    if mp4:
        # ~ resp = httptools.downloadpage(mp4, follow_redirects=False, only_headers=True, headers=CUSTOM_HEADERS)
        # ~ if int(resp.headers['content-length']) < 50000000: # Menos de 50 mb es que no debe ser válido
            # ~ return 'El vídeo no es válido'
        
        rtmp = scrapertools.find_single_match(data, '\{file\s*:\s*"(rtmp:[^"]+)')
        if rtmp:
            playpath = scrapertools.find_single_match(rtmp, 'mp4:.*$')
            rtmp = rtmp.split(playpath)[0] + ' playpath=' + playpath + ' swfUrl=http://gamovideo.com/player61/jwplayer.flash.swf'
            video_urls.append(["rtmp", rtmp])

        video_urls.append(["mp4", mp4])

    return video_urls
