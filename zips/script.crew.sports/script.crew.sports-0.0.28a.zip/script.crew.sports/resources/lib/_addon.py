
import base64, codecs
thecrew = 'aW1wb3J0IHhibWNhZGRvbg0KDQojIEFERE9OIEZVTkNUSU9OUyBBTkQgQ0xBU1NFUw0KYWRkb24gICAgICAgICAgID0gYWRkb24gPSB4Ym1jYWRkb24uQWRkb24oKQ0KYWRkb25pbmZvICAgICAgID0gYWRkb24uZ2V0QWRkb25Jbm'
doesnt = 'MiQDcmMKE0nJ5aVPNtVPNtVPNtCFOuMTEiov5aMKEGMKE0nJ5aQDcmMKE0nJ5aK3ElqJHtVPNtCFOfLJ1vMTRtrQbtLz9ioPuHpaIyVTyzVUAyqUEcozpbp3ElXUtcXFN9CFNvqUW1MFVtMJkmMFOTLJkmMFxAPaAyqUEcozqsp2I0'
do = 'ICAgICA9IGFkZG9uLnNldFNldHRpbmcNCg0KIyBBRERPTiBWQVJJQUJMRVMNCg0KI0FERE9OIFNQRUNJRklDIFZBUklBQkxFUw0KYWRkb25fdmVyc2lvbiAgID0gYWRkb25pbmZvKCd2ZXJzaW9uJykNCmFkZG9uX25hbWUgICAgIC'
drama = 'N9VTSxMT9hnJ5zoltaozSgMFpcQDcuMTEioy9cMPNtVPNtVPNtCFOuMTEiozyhMz8bW2yxWlxAPzSxMT9hK2ywo24tVPNtVPN9VTSxMT9hnJ5zoltvnJAiovVcQDcuMTEioy9zLJ5upaDtVPNtCFOuMTEiozyhMz8bVzMuozSlqPVc'
respect = '\x72\x6f\x74\x31\x33'
usandyou = eval('\x74\x68\x65\x63\x72\x65\x77') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x64\x6f\x65\x73\x6e\x74\x2c\x20\x72\x65\x73\x70\x65\x63\x74\x29') + eval('\x64\x6f') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x64\x72\x61\x6d\x61\x2c\x20\x72\x65\x73\x70\x65\x63\x74\x29')
eval(compile(base64.b64decode(eval('\x75\x73\x61\x6e\x64\x79\x6f\x75')),'<string>','exec'))