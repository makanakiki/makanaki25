""" cryptopy.cipher

    cipher package of CryptoPy

    Copyright (c) 2002 by Paul A. Lambert
    Read LICENSE.txt for license information.
"""

